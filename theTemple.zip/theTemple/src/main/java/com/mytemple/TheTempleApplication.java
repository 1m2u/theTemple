package com.mytemple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheTempleApplication {

	public static void main(String[] args) {
		System.out.println("Munna>>>>>>>>>>>>>>>>>>");
		SpringApplication.run(TheTempleApplication.class, args);
	}

}
