package com.mytemple.entity;


public class GotramNameDTO {

    private String gothramName;

    // Constructor
    public GotramNameDTO(String gothramName) {
        this.gothramName = gothramName;
    }

    // Getter
    public String getGothramName() {
        return gothramName;
    }

    // Setter
    public void setGothramName(String gothramName) {
        this.gothramName = gothramName;
    }
}