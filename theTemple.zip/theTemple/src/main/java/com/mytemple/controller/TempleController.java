package com.mytemple.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mytemple.entity.Gotram;
import com.mytemple.entity.GotramNameDTO;
import com.mytemple.service.GotramService;

@RestController
@RequestMapping("/mytemple")
public class TempleController {

	@Autowired
    private GotramService gotramService;

    @GetMapping("/gotrams")
    public List<GotramNameDTO> getGotramName() {
        return gotramService.getGotramName();
    }
}
