package com.mytemple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheTempleApplicationTests {

	@Test
	void contextLoads() {
	}

}
